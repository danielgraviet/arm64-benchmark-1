# Graviton5 (m9gd.metal-48xl) findings, 2026-10-14

The software is identical to HQ Vera (same binary checksums). Runs are 1,000-sandbox create-ready bursts (bench recipe) plus the
published dense agent ladder (n=45, seed 42, -E 8, hold-then-exec, cpu 0.025/max 1, mem 0.0625/max 4, disk 16 MiB, pool 512).
Raw data is in `bench-results.tgz` (`suite-4k-*`, `suite-64k-*`, `memprobe-*`).
Layouts: UNPIN = sandboxes on both NUMA nodes (192 cores); PIN-N0 = node 0 only (96 cores, its own memory). The control plane is never pinned.

## 1. One node vs both (4 KiB kernel)
- Startup, 1k: both nodes 9.4 s median (7.1–13.8) vs one node 15.3 s (14.8–18.6). **Pinning is slower**, the reverse of Vera
  (Vera: one socket 8.4–10.6 s vs both 20–23 s). Crossing nodes on Graviton5 costs nothing visible; halving the cores does.
- Throughput: both nodes plateau at **22.9 jobs/s**, one node at **11.9 jobs/s**, so scaling across nodes is exactly linear.
- Zero failures through c=2000 (both nodes) and c=1408 (one node). 0 socket timeouts and 0 self-cordons in every run.

## 2. Client processes (control plane)
Accept p50: 1 proc 4.3 s → 4 procs 0.49 s → 8 procs 0.24 s → 16 procs **0.12 s** (Vera: 0.23–0.50 s at 16). All-ready does not
improve (7.7 → 9.8 s): as on Vera, the runner/guest side bounds a 1k burst, not the API.

## 3. 4 KiB vs 64 KiB pages (same kernel 6.17.0-1017-aws, one reboot)
| | 4 KiB | 64 KiB |
|---|---|---|
| 1k startup, both nodes (median, 6 reps) | 9.4 s | 9.9 s |
| 1k startup, one node | 15.3 s | 18.6 s |
| ladder plateau, both nodes | 22.9 /s | 23.2 /s (+1.5%) |
| ladder plateau, one node | 11.9 /s | 12.1 /s |
| job duration at light load (c=44–176) | 6.65–6.72 s | 6.63–6.73 s |
| `echo ready` probe p50 | ~50 ms | ~28 ms |
| host RAM per idle sandbox (500 kept clones; RssAnon / node delta) | 129 / 173 MiB | 139 / 190 MiB (+8–10%) — **corrected, see §5** |
| host RAM per sandbox under agent load (c=704) | 215 MiB | 233 MiB (+8%) |
| one node, c=1408 | 0 failures | **node 0 out of memory**: 67 firecrackers, 9 postgres processes and the harness were OOM-killed |
- 64 KiB pages do not make the CPU work faster (≤1.5%). They cost about **8% more host memory per sandbox**, which is enough to
  push one 377 GiB node past its limit at 1,408 sandboxes (≈1408 × 233 MiB vs 1408 × 215 MiB).
- Caveat: the 64 KiB suite ran on a template snapshot minted under the 4 KiB kernel (templates live in `scratch/snapshots`, not `templates/`).

## 4. Comparison with the published ladders (one Vera socket; AMD whole chip)
| host | cores | light-load job | plateau jobs/s | jobs/s per core |
|---|---|---|---|---|
| Vera, socket 0 (88 c / 176 threads) | 88 | 5.9 s | ~13.0 | 0.148 |
| **Graviton5, both nodes** | 192 | 6.65 s | **22.9** | 0.119 |
| Graviton5, one node | 96 | 6.65 s | 11.9 | 0.124 |
| EPYC 9575F | 64 | 6.7 s | ~8.1 | 0.127 |
| EPYC 9755 | 128 | 7.1 s | ~11.0 | 0.086 |
Vera is ~11% faster per job and ~20% higher per core. Graviton5 wins on total throughput through core count (2.2× Vera's socket),
and it holds 2000 with zero failures (Vera's published 2000 point had 53–627 failures).
Caveat: the published Vera/AMD ladders used a 1 GiB disk; these runs used 16 MiB (disk size was ruled out on the 9575F).

## Incidents
- 64 KiB, one node, c=1408: the node-0 OOM also killed the user session, so the suite's trap never ran. rlp.slice stayed pinned and
  1,237 firecrackers were orphaned. Recovered with an unpin, a runner restart and `g5-netreset.sh`. Postgres auto-recovered.

## 5. Investigation (follow-up, same day)

### 5.1 The 1k startup burst is dominated by the benchmark image's own entrypoint
- Templates are *pre-entrypoint* snapshots, so every clone runs the image CMD after resume:
  `python -m workload.agent --n 30 --seed 42`. That costs **~4.1 CPU-s per sandbox** (one clone: 4.18 s of FC CPU in 3 s, then idle).
- CPU accounting for a 1k burst (UNPIN, 9.2 s): host **191 of 192 cores busy**. Guests use **1,637 core-s**, and another 3,460 core-s
  follow in the next 20 s. Platform: runner 22, API 2, proxy 1, Postgres 3, client 14 core-s, i.e. **~28 ms of platform CPU per sandbox**.
- Same burst with `python:3.12-slim` (CMD exits at once): **1k all-ready in 3.8 s**, host 30% busy, guests 74 core-s.
- So the "1,000 sandboxes ready" numbers on every platform measure how fast the host chews through 1,000 concurrent agent
  episodes alongside the spawns, not platform startup. This is why startup scales with cores × per-core speed.
- The throughput ladder carries it too: each sandbox's entrypoint adds ~4 core-s against 8 jobs × ~7 core-s, about 7%, the same
  proportion on every platform.

### 5.2 Why pinning hurts here and helped on Vera
- Cross-node latency on Graviton5 (pointer chase, 2 GiB): local 129 ns, remote 156–168 ns → **1.2–1.3×**. The vanilla study
  measured 1.30× on Graviton5 and **3.08× on Vera** (129 → 399 ns).
- The burst is CPU-bound (5.1). With half the cores and near-free remote memory, pinning only removes capacity. Runner phases
  (journald boot-phases, 4 KiB): FC spawn p50 **14 ms unpinned vs 255 ms pinned** (p95 0.4 vs 2.1 s). The spawn is starved of CPU.
  On Vera the remote-latency penalty dominates instead.

### 5.3 Memory per sandbox: correction and breakdown
- **The earlier "2.3× on 64 KiB" was my measurement error.** That 64 KiB probe ran right after I had wiped the templates, so
  412 of 500 sandboxes cold-booted (full boot, no snapshot). Re-measured with clones: 139 vs 129 MiB RssAnon idle (+8%), and
  233 vs 215 MiB under agent load (+8%).
- One clone (4 KiB): 145 MiB RSS, of which 116 MiB is private CoW of the template memory and 26 MiB is shared page cache.
  85% of the private pages are fresh writes into pages that were zero in the template (guest RAM offsets 2.0–2.2 GiB).
  - `python:3.12-slim` clone: 46 MiB private. The agent image's entrypoint adds about 70 MiB (python, imports, page cache).
  - 64 KiB: 60 MiB (slim) and 127 MiB (agent) private, so the amplification is small because guest writes are clustered.
- The guest sees 4 GiB and uses about 143 MiB of it. Host RSS tracks what the guest touches after resume.

### 5.4 Per-core speed light vs packed (guest-cgroup PMU counters, published recipe)
| c | jobs/s | job p50 | core-s/job | effective GHz | IPC |
|---|---|---|---|---|---|
| 96 (half the cores) | 13.07 | 6.69 s | 7.34 | 3.30 | 5.31 |
| 352 (packed) | 22.68 | 13.40 s | 7.90 | 3.21 | 5.08 |
Graviton5 runs at a fixed 3.3 GHz and loses only ~3% clock and ~4% IPC when packed (9575F: −24% clock; OCI Vera: −6%).
Its per-job gap to Vera is single-thread speed (6.65 s vs 5.9 s at light load); both hold that speed under full load.
core-s/job includes each sandbox's entrypoint (5.1), so the pure job is about 6.8 core-s.

### Incidents during the investigation
- None. The host was rebooted 64 KiB → 4 KiB for the memory A/B; it is back on 4 KiB, unpinned, with no sandboxes.
