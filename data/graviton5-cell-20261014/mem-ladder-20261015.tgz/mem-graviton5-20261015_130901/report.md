# Memory-bandwidth ladder (STREAM-style triad, one vCPU per sandbox)

| sandboxes | rep | ok | aggregate GB/s | per-sandbox GB/s p50 / min | start skew s | overlap s | processor W | GB/s per W | busy GHz |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 1/1 | 57.91 | 57.907 / 57.907 | 0.0 | 30.004 | nan | nan | nan |
| 1 | 2 | 1/1 | 56.99 | 56.993 / 56.993 | 0.0 | 30.005 | nan | nan | nan |
| 8 | 1 | 8/8 | 365.13 | 45.595 / 45.042 | 0.005 | 29.996 | nan | nan | nan |
| 8 | 2 | 8/8 | 337.65 | 45.801 / 35.002 | 0.006 | 29.999 | nan | nan | nan |
| 32 | 1 | 32/32 | 594.21 | 17.938 / 16.158 | 0.026 | 29.981 | nan | nan | nan |
| 32 | 2 | 32/32 | 593.86 | 18.554 / 18.218 | 0.022 | 29.978 | nan | nan | nan |
| 64 | 1 | 64/64 | 603.94 | 8.839 / 7.781 | 0.054 | 29.961 | nan | nan | nan |
| 64 | 2 | 64/64 | 603.87 | 8.839 / 7.253 | 0.06 | 29.95 | nan | nan | nan |
| 128 | 1 | 128/128 | 571.64 | 4.427 / 3.553 | 0.109 | 29.918 | nan | nan | nan |
| 128 | 2 | 128/128 | 572.01 | 4.33 / 3.324 | 0.109 | 29.905 | nan | nan | nan |
| 176 | 1 | 176/176 | 582.41 | 3.295 / 2.738 | 0.189 | 29.865 | nan | nan | nan |
| 176 | 2 | 176/176 | 582.17 | 3.257 / 2.651 | 0.209 | 29.83 | nan | nan | nan |

Aggregate GB/s is the sum of per-sandbox mean triad rates and is valid only when start skew is small against the run length (overlap ≈ run length). STREAM convention: 3 × 8 bytes per element per pass; write-allocate traffic is not counted.
