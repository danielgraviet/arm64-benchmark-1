# phoenix-e6 bench cell — configuration and first results

**Host:** OCI Phoenix `BM.DenseIO.E6.Ax.192`, `<turin-host>` (private `10.6.2.170`), login `ubuntu`,
hostname `vedran-test`. Built 2026-10-14.

**Why this cell exists:** a like-for-like rerun of the HQ Vera benchmark on AMD EPYC 9J45 (Turin),
using the same Daytona build, the same client and the same recipe, so the Vera numbers have an
x86 comparison that is not confounded by software differences.

## Hardware

| | |
|---|---|
| CPU | AMD EPYC 9J45 (Turin), 2 sockets x 96 cores, SMT2 → 384 threads, boost 4.12 GHz, governor `performance` |
| NUMA | node0 = 0-95,192-287 · node1 = 96-191,288-383 · L3 1 GiB (32 instances) |
| Memory | 2,267 GiB |
| Disk | 12 x 6.8 TB Solidigm NVMe. **Only `nvme0n1` is used** (ext4, `/mnt/data`, 6.9 TB) |
| Kernel | `6.17.0-1020-oracle`, page size **4 KiB** |
| Network | 2 x 200 Gbit (`enp19s0`) |

### Storage deviates from the OCI default, deliberately

Cloud-init had assembled all 12 NVMe into a RAID10 (`md127`, 42 TB xfs) that was **1.7 % into a
60-hour initial resync** — every snapshot restore would have competed with it. HQ Vera, the host
being matched, has **no RAID**: one NVMe carries root and `/mnt/data/rlp`. The array was empty, so
it was stopped and the superblocks zeroed; `/mnt/data` is now plain ext4 on `nvme0n1`.
`nvme1n1`..`nvme11n1` are unused and free for a RAID0 A/B later.

## Software — identical to the HQ Vera cell

| | |
|---|---|
| Daytona | `f0611fa13` + cherry-pick `6883d3366` (EROFS `-b 4096`) + the `RLP_FC_SOCK_WAIT_MS` knob + `8d2b090ff` `RLP_FC_SMT` (inactive), built x86_64 on the box |
| Firecracker | stock v1.16.1, sha `2fd0171309af…` (the sha pinned in `deploy/bin/SHA256SUMS`) |
| Guest kernel | `vmlinux-6.8.12-rlp3`, copied from the 9575F cell |
| In-guest daemon | `rlp-rs-0.4.1` layer, copied from the 9575F cell — the daemon every AMD cell runs |
| Client | Daniel's harness + the eng `rlp` SDK, copied from the 9575F cell |
| Backing services | Postgres 16 and NATS 2.10 in host-network containers, `synchronous_commit=off` |

Binary shas: `rlp-api d5f5…`/`84a383bcceb7`, `rlp-runner d5f501e813a0`, `rlp-proxy f7a0da7a419f`,
`firecracker 2fd0171309af`. Full config: `/etc/rlp/{BUILD,api.env,runner.env,proxy.env,regions.json}`,
host changes: `/etc/rlp/HOSTCHANGES`.

Cell identity: region `phoenix-e6`, runner `phoenix-e6-1`, cpu type `turin-9j45`, harness target
`phoenix-e6`.

### Host posture (every gate from `docs/benchmark-methodology.md`)

ARP `gc_thresh3` 65536 (v4+v6), conntrack 1M, `nr_hugepages=0`, `nofile` 1,048,576,
`numa_balancing=0` (HQ Vera boots `numa_balancing=disable`), the unfiltered open-iscsi udev rule
shadowed for `rlp*|veth*|tap*|fc*`, `libvirtd`/`fwupd` stopped and runtime-masked, hostname pinned
in `/etc/hosts`. `bench-preflight` is installed at `/usr/local/bin/bench-preflight` and gates every
rep.

## Results — 1,000 and 2,000 sandboxes create-ready

Recipe: `dtgraviet/vera-agent-benchmark:v3`, cpu 0.025 / mem 64 MiB / disk 1 GiB, warm snapshot
clones, probe `echo ready`. `ready_wall_s` = burst start → last sandbox ready **and probed**.

### 1,000, one client process (directly comparable to the HQ Vera pin-ab runs)

| arm | rep1 | rep2 | rep3 | failures | fc-socket timeouts | self-cordons |
|---|---:|---:|---:|---:|---:|---:|
| socket 0 only (96c/192t) | 10.22 s | 10.77 s | 10.80 s | 0 | 0 | 0 |
| whole box (192c/384t) | 11.21 s | 10.61 s | 10.92 s | 0 | 0 | 0 |

### 1,000 and 2,000, 16 client processes (`mpfleet.py`, the methodology's burst client)

| arm | n=1,000 | n=2,000 | failures |
|---|---|---|---:|
| whole box (192c/384t) | **7.90 / 8.01 / 7.97 s** | **22.30 / 21.94 s** | 0 |
| socket 0 only (96c/192t) | 12.52 / 11.89 / 11.87 s | 29.55 / 30.97 s | 0 |

Every rep above landed all 1,000 / 2,000 sandboxes ready and probed, with zero fc-socket timeouts
and zero self-cordons.

Runner-side per-clone time at low load: `template=hit total_ms≈84–108`
(`scratch_cp≈42 ms`, `fc_start≈12 ms`, `load≈5 ms`, `toolbox_wait≈17 ms`).

## What these results say so far

1. **The box matches HQ Vera on startup.** 1,000 ready in **7.9 s** whole-box / **10.2 s** on one
   socket, against HQ Vera's 8.4–10.6 s pinned to one socket. 2,000 in **21.9-22.3 s** against Vera's
   27.4 s (the published HQ figure). No failures, no fc-socket timeouts, no self-cordons in any run.
2. **Vera's NUMA penalty does not reproduce here.** On Vera, spreading across both sockets cost
   2.3x (8.4–10.6 s → 20–23 s). On this EPYC, unpinned is within noise of pinned with the
   single-process client (10.6–11.2 vs 10.2–10.8 s), and with 16 client processes the whole box is
   **faster** than one socket at both sizes (1k: 7.9-8.0 vs 11.9-12.5 s; 2k: 21.9-22.3 vs
   29.6-31.0 s) - once the client is no longer the bottleneck, the second socket helps instead of
   hurting. Pinning on this box mostly starves the client.
3. **The single-process client is again the limiter at 1k.** Same host, same runs: 1 process
   10.2–10.8 s with `accept_p50` 4.6–4.8 s; 16 processes 7.9 s with `post_p50` 0.22 s. This
   reconfirms the HQ Vera finding that `post_s` from a one-process client is harness queueing, not
   control-plane time.
4. **Deliberate deviation to be aware of when comparing to other OCI boxes:** this cell runs on one
   NVMe, not the 12-disk RAID10 the OCI image builds.

## Open / next

- A density ladder beyond 2,000 (`RLP_MAX_LIVE_VMS=3000`, `RLP_NETNS_POOL=2100`
  currently cap it; the box has 2.2 TB of memory and 192 cores, so it should go far higher).
- The agent-throughput ladder (jobs/s plateau), which is the other published number.
- `RLP_VM_MAXACK` A/B: this cell runs the stock 256 in-flight create cap, like HQ Vera. The 9575F
  runs 2048.
- RAID0 across all 12 NVMe as a storage A/B, if the single-drive restore path ever shows up as the
  limit.
## Concurrency ceiling — 2026-10-14

**Result: 8,000 concurrent sandboxes, and nothing in the hardware stopped us.** Every ceiling hit
was a configured limit; the box was at 21 % of memory, 55 % of its CPU reservation budget and 7 %
of its scratch budget when the last one tripped.

Method: `mpfleet.py --procs 16` against `alpine:3.20` (idle entrypoint — per §0 of the methodology,
the agent image would have measured CPU throughput instead), in waves that are kept alive, each
wave probed with `echo ready`. Run dirs: `/mnt/data/bench/{ladder,waves}-*`.

### The ladder

| what was run | result | what actually stopped it |
|---|---|---|
| single burst, 1,000 | 7.95 / 7.96 s, 0 failed | — |
| single burst, 2,000 | 23.2 s, 0 failed | — |
| single burst, 3,000 | 42.7 s, 0 failed | — |
| single burst, 4,000 | 81.9 s, 0 failed | — |
| single burst, 5,000 | 3,941 of 5,000 | **60 s create-pickup cap.** 962 of the failures are `create job not picked up by any runner within 60s`. `CREATE_MAX_QUEUE_SECS_CAP` is a hard-clamped constant (`api/src/events/mod.rs:437`); `RLP_CREATE_MAX_QUEUE_SECS` cannot raise it |
| waves of 1,000, 1 GiB scratch | **6,742** held | **scratch reservation.** Runner gate: `reserved ScratchMiB 6,903,808` vs `95 % × 7,266,782`. 6,903,443 ÷ 1,024 = 6,741. Reproduced to ±1 across four runs, with the cap raised to 900 s and `RLP_MAX_LIVE_VMS` at 8,000 and 20,000 |
| waves of 2,000, 64 MiB scratch | **8,000** held | **API overload shed.** `RLP_MAX_QUEUED_CREATES` (default 8000, `api/src/state.rs:429`) → `429 create queue at capacity`, rejecting all 2,000 of wave 5 in 0.3 s |

Wave timings at 64 MiB scratch were flat all the way up: 2,000 sandboxes ready in 10.5 s, 10.3 s,
12.3 s, 12.7 s for waves 1–4 (i.e. the 7,999th sandbox starts as fast as the first).

### Headroom at 8,000 live

| resource | used | budget |
|---|---|---|
| memory | 406 GiB (`MemAvailable` 2,200 → 1,794 GiB) | 2,267 GiB |
| runner CPU reservation | 200 of 364.8 (0.025 × 8,000) | 95 % × 384 |
| scratch reservation | 500 GiB (64 MiB × 8,000) | 95 % × 6.9 TB |
| netns | 8,000 of 14,200 created | pool auto-grows |
| guest IPs | 8,000 | /18 = 16,382 |

Extrapolating the first binding *hardware* constraint: CPU reservation at 0.025/sandbox runs out at
**14,592**, memory at 64 MiB/sandbox at ~34,000.

### Three things worth knowing before the next density run

1. **Scratch is reserved, not used.** At 6,742 sandboxes the reservation was 6.9 TB while actual
   use was 110 GB (~16 MiB each). A 1 GiB `disk` in the recipe costs 64× its real footprint and is
   what caps a 7 TB host at 6.7k. Ask for what you use.
2. **The netns pool refill is the slowest thing on the box.** Growing it (2,100 → 6,200, then each
   +4,000 as the fleet consumes it) takes 15–20 minutes at load > 1,000, during which SSH barely
   responds and no benchmark is valid. Size it before a ladder, not during one, and let the
   preflight's `netns_pool_warm` gate hold you.
3. **Tearing down thousands of sandboxes is minutes, not seconds** (6,742 → 0 took ~7 min). Budget
   it between levels; a rep started on a dirty host fails the preflight for a reason.

### Cell changes made for this ladder (see `/etc/rlp/HOSTCHANGES`)

- `CREATE_MAX_QUEUE_SECS_CAP` 60 → 900 in the cell's own API build, plus
  `RLP_CREATE_MAX_QUEUE_SECS=600`. **Bench cell only** — the 60 s cap exists so a create with no
  capacity fails fast with a truthful error. Revert by rebuilding from a clean tree.
- `RLP_MAX_LIVE_VMS` 3000 → 20000, `RLP_NETNS_POOL` 2100 → 6200, `RLP_SUBNET_CIDR` /20 → /18
  (a /20 is 4,094 usable addresses and would itself have capped the host).
- `kernel.numa_balancing=0`, matching HQ Vera's boot line.
### Past 8,000: the ceiling is the runner's heartbeat, not the hardware

With `RLP_MAX_QUEUED_CREATES=40000` the shed gate stops binding and the ladder goes further:

| wave | cumulative live | wave wall | failures |
|---|---:|---:|---:|
| 1 | 2,000 | 10.3 s | 0 |
| 2 | 4,000 | 10.3 s | 0 |
| 3 | 6,000 | 12.3 s | 0 |
| 4 | 8,000 | 14.7 s | 0 |
| 5 | **9,750** | 224.7 s | 250 (`failed to start, reason=None`) |

**Peak: 9,750 concurrent sandboxes / 9,946 firecracker processes, with 1,696 GiB of memory still
free.** But the run ended in a control-plane failure, not a resource one:

```
20:26:53  wave4 complete — 8,000 live, 0 failures
20:27:38  rlp-api: "runner phoenix-e6-1 marked lost"
21:06:21  wave5 — 250 failures; vms: 9,876 lost / 124 running, while 9,946 firecrackers are alive
```

**What happened.** Under the load of ~8–10k guests (plus the netns pool growing by 4,000), the
runner's heartbeat starved past the reaper's threshold. The API marked the *runner* lost, and the
`lost_sweep` (`api/src/events/maintenance.rs:5199`) then marked every ephemeral VM on that runner
terminally `lost` — 9,876 of them, all of which were running and had answered `echo ready` moments
earlier. The runner returned to `online` on its own once the load dropped, but the rows stay
terminal, so the delete path can no longer reach those guests: **9,946 orphaned firecrackers that
only a `pkill` recovers.**

This is very likely the same mechanism behind the "runner crashed / `no matching capacity` /
thousands of leftover firecrackers" reports from the Phoenix, RedSwitches and Vultr boxes. It is a
density-induced liveness failure with a destructive cleanup, not a crash.

A second scaling limit sits next to it and is cosmetic by comparison: adoption verification is
capped at 4,096 VMs per host (`contract.AdoptionCheckMaxIDs`, whose comment reads "a host with 4096
adopted VMs is broken in a way this feature cannot help with"). Above that the runner logs
`adopt verify: adopted set exceeds the batch cap; skipping the check` and the check is permanently
inconclusive — it fails open, so it does not kill guests, but this host runs twice that routinely.

### So what is the ceiling?

| question | answer |
|---|---|
| comfortably, with clean bookkeeping | **8,000** — waves of 2,000 at 10–15 s each, zero failures |
| maximum observed alive | **9,750** (9,946 firecracker processes) |
| hardware limit | not reached — 1.7 TB memory free, CPU reservation 55 %, scratch 7 %, IPs 60 % |
| first hardware limit, extrapolated | CPU reservation at 0.025/sandbox → **14,592** |
| what actually stops it | the runner's heartbeat under its own load, followed by the lost-sweep |

To go higher the control plane has to survive the density: a heartbeat that does not starve behind
create work (or a reaper threshold that accounts for it), and a lost-sweep that does not terminally
reap a fleet whose guests are provably alive.
