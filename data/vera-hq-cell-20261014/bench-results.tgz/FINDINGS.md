# HQ Vera bench cell — findings log

Cell: daytona f0611fa13 + EROFS 4k (#1060) + RLP_FC_SOCK_WAIT_MS knob (#3212) + RLP_FC_SMT (inactive);
daemon rlp-rs-0.4.1; stock Firecracker v1.16.1; kernel 6.17.0-1032-nvidia-64k; preempt=none; 600 W cap.
Workload: create-ready, 0.025 CPU / 64 MiB / 1 GiB disk / 1 vCPU, probe `echo ready`, client pool 1024 (4096 at 2k).

## Ruled out (measured on this host)
| factor | result | data |
|---|---|---|
| **toolbox proxy capacity** | **ruled out** — 1 proxy vs LB->1 vs LB->4: identical medians, p95s and `echo ready` latency (p50 30-47 ms, p99 190-380 ms) at 1k and 2k; one proxy uses ~1 CPU-s per 1k burst, ~5 CPU-s per 2k | proxy-scale-20261014_081213 |
| event auditing (RLP_EVENT_AUDIT) | no effect (21-22.6 s all-ready on/off, unpinned) | audit-ab-20261014_064901 |
| API restart / accumulated rows | no effect (30 -> 15,080 vms rows, API up 0-35 min) | audit-ab, pin-ab |
| second socket for the control plane | not needed — everything on one 88-core socket gives the same all-ready time as control plane on socket 1 | cp-split-20261014_074122 |
| NVIDIA SMT Firecracker fork (1 vCPU guests) | no effect (fork inert below 2 vCPUs) | fc-arms-20261014_013902 (arms A/B; NOTE: Daniel's drop-ins were active) |
| FC API-socket spawn wait 3 s vs 30 s | removes all spawn timeouts + self-cordons, medians unchanged | fcsock-ab-vera-20261014_003117 (#3212) |

## Confirmed
- **NUMA locality of the data path is the startup lever on dual-socket Vera**: runner+sandboxes pinned to socket 0
  -> 1,000 ready in 8.4-10.6 s (median 5.3-5.9 s); unpinned across both sockets -> 20-23 s (median 7.7-11.4 s). (pin-ab, cp-split)
- Dedicated cores for the client/control plane cut "accept" ~5.3 s -> ~3.0 s and median ready ~5.5 -> ~4 s, but not all-ready.
- Guest hangs after snapshot resume: ~1 in 10,000 1-vCPU clones (daemon answers; the spawned command never finishes);
  2-vCPU clones 20-55% (#3213). Not proxy-related (seen with every proxy topology; error is generated in-guest).

- **"Accept" (harness post_s) is mostly the benchmark client, not the API.** Same 1k burst from 1/4/8/16 client
  processes: accept p50 2.9-5.8 s -> 1.3-1.7 -> 0.6-1.1 -> 0.23-0.50 s, while all-ready stays 9-12 s (time moves into
  "wait for running"). The API takes 1,000 concurrent creates in <0.5 s median; a 1k burst is limited by the runner/guest
  side. Per-phase tables that call post_s "control plane accepts the request" mislabel client queueing. (client-split-20261014_091923)

## Open
- Guest hang after snapshot resume (~1e-4 for 1 vCPU) - #3213.
- What bounds the runner/guest side of a 1k burst at ~9-10 s on one socket (vs ~20 s unpinned).
