# Memory-bandwidth ladder (STREAM-style triad, one vCPU per sandbox)

| sandboxes | rep | ok | aggregate GB/s | per-sandbox GB/s p50 / min | start skew s | overlap s | processor W | GB/s per W | busy GHz |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 1/1 | 45.13 | 45.135 / 45.135 | 0.0 | 30.002 | 102 | 0.441 | 5.04 |
| 1 | 2 | 1/1 | 47.08 | 47.081 / 47.081 | 0.0 | 30.002 | 103 | 0.456 | 5.06 |
| 8 | 1 | 8/8 | 262.4 | 32.88 / 32.487 | 0.005 | 29.997 | 204 | 1.287 | 5.01 |
| 8 | 2 | 8/8 | 260.91 | 32.634 / 32.176 | 0.006 | 29.996 | 204 | 1.279 | 5.01 |
| 32 | 1 | 32/32 | 299.84 | 9.365 / 9.189 | 0.073 | 29.949 | 279 | 1.075 | 5.02 |
| 32 | 2 | 32/32 | 299.71 | 9.376 / 9.234 | 0.084 | 29.92 | 281 | 1.066 | 5.02 |
| 64 | 1 | 64/64 | 301.45 | 4.707 / 4.617 | 0.282 | 29.744 | 329 | 0.917 | 4.98 |
| 64 | 2 | 64/64 | 302.11 | 4.711 / 4.643 | 0.384 | 29.643 | 353 | 0.856 | 4.99 |
| 128 | 1 | 128/128 | 305.24 | 2.373 / 2.304 | 1.021 | 29.06 | 366 | 0.834 | 5.00 |
| 128 | 2 | 128/128 | 305.11 | 2.374 / 2.103 | 1.014 | 29.068 | 366 | 0.833 | 5.00 |

Aggregate GB/s is the sum of per-sandbox mean triad rates and is valid only when start skew is small against the run length (overlap ≈ run length). STREAM convention: 3 × 8 bytes per element per pass; write-allocate traffic is not counted.
