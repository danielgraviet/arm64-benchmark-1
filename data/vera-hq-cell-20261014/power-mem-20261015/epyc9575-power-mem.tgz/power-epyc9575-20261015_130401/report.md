# Jobs per watt

sampler: # domains=rapl_pkg_s0 wall=ipmi cpufreq=yes host=hosted.redswitches.com

Idle (89 samples): processor_w 54 W, wall_w 133 W

| level | jobs/s | failures | processor_w (W) | wall_w (W) | jobs/s per processor W ×1000 | J per job (processor) | J per job above idle | busy-core GHz | busy CPUs |
|---|---|---|---|---|---|---|---|---|---|
| 44 | 5.91 | 0 | 399 | 430 | 14.8 | 67.4 | 58.3 | 4.33 | 39 |
| 176 | 7.98 | 0 | 367 | 683 | 21.7 | 46.0 | 39.2 | 3.62 | 122 |
| 352 | 7.93 | 0 | 374 | 692 | 21.2 | 47.2 | 40.4 | 3.65 | 126 |
| 704 | 8.03 | 0 | 379 | 700 | 21.2 | 47.2 | 40.5 | 3.66 | 127 |
| 2000 | 8.02 | 0 | 382 | 717 | 21.0 | 47.7 | 41.0 | 3.69 | 127 |

processor_w = Vera 'AP Power' (both sockets) or AMD RAPL package (both sockets); module_w = Vera 'Total Power' incl. on-module memory; wall_w = BMC reading if available. Confirm the Vera domain definitions before quoting; AMD RAPL excludes DRAM.
