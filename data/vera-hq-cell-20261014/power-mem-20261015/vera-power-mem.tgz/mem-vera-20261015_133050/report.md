# Memory-bandwidth ladder (STREAM-style triad, one vCPU per sandbox)

| sandboxes | rep | ok | aggregate GB/s | per-sandbox GB/s p50 / min | start skew s | overlap s | processor W | GB/s per W | busy GHz |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 0/1 | 0 | None / 0 | None | None | nan | nan | nan |
| 1 | 2 | 0/1 | 0 | None / 0 | None | None | nan | nan | nan |

Aggregate GB/s is the sum of per-sandbox mean triad rates and is valid only when start skew is small against the run length (overlap ≈ run length). STREAM convention: 3 × 8 bytes per element per pass; write-allocate traffic is not counted.
