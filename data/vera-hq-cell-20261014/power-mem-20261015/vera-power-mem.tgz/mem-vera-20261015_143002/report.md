# Memory-bandwidth ladder (STREAM-style triad, one vCPU per sandbox)

| sandboxes | rep | ok | aggregate GB/s | per-sandbox GB/s p50 / min | start skew s | overlap s | processor W | GB/s per W | busy GHz |
|---|---|---|---|---|---|---|---|---|---|
| 1 | 1 | 1/1 | 72.46 | 72.463 / 72.463 | 0.0 | 30.001 | nan | nan | nan |
| 1 | 2 | 1/1 | 72.06 | 72.065 / 72.065 | 0.0 | 30.004 | nan | nan | nan |
| 8 | 1 | 8/8 | 550.83 | 69.832 / 64.936 | 0.011 | 29.99 | nan | nan | nan |
| 8 | 2 | 8/8 | 570.34 | 72.782 / 65.703 | 0.011 | 29.992 | nan | nan | nan |
| 32 | 1 | 32/32 | 1019.21 | 31.826 / 31.17 | 0.061 | 29.944 | nan | nan | nan |
| 32 | 2 | 32/32 | 1014.57 | 32.128 / 18.535 | 0.047 | 29.956 | nan | nan | nan |
| 64 | 1 | 64/64 | 1743.63 | 22.932 / 22.57 | 0.104 | 29.897 | nan | nan | nan |
| 64 | 2 | 64/64 | 1852.51 | 23.939 / 23.579 | 0.088 | 29.923 | nan | nan | nan |
| 128 | 1 | 127/128 | 2123.72 | 12.865 / 12.517 | 0.233 | 29.774 | nan | nan | nan |
| 128 | 2 | 127/128 | 2125.37 | 13.604 / 13.161 | 0.21 | 29.797 | nan | nan | nan |
| 176 | 1 | 174/176 | 2099.44 | 12.066 / 8.481 | 0.284 | 29.724 | nan | nan | nan |
| 176 | 2 | 176/176 | 2108.42 | 11.875 / 8.321 | 0.299 | 29.714 | nan | nan | nan |
| 256 | 1 | 256/256 | 2070.37 | 5.043 / 4.16 | 0.617 | 29.388 | nan | nan | nan |
| 256 | 2 | 255/256 | 2067.67 | 5.976 / 4.736 | 0.566 | 29.437 | nan | nan | nan |
| 352 | 1 | 351/352 | 1356.9 | 3.497 / 2.039 | 1.497 | 28.506 | nan | nan | nan |
| 352 | 2 | 351/352 | 1406.26 | 3.493 / 2.079 | 1.021 | 29.007 | nan | nan | nan |

Aggregate GB/s is the sum of per-sandbox mean triad rates and is valid only when start skew is small against the run length (overlap ≈ run length). STREAM convention: 3 × 8 bytes per element per pass; write-allocate traffic is not counted.
