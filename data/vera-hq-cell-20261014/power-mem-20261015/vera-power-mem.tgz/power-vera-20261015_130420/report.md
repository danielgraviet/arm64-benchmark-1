# Jobs per watt

sampler: # domains=vera_ap_s0,vera_ap_s1,vera_cpu_s0,vera_cpu_s1,vera_dram_s0,vera_dram_s1,vera_soc_s0,vera_soc_s1,vera_total_s0,vera_total_s1 wall=none cpufreq=yes host=localhost

Idle (88 samples): dram_w 17 W, module_w 282 W, processor_w 225 W

| level | jobs/s | failures | dram_w (W) | module_w (W) | processor_w (W) | jobs/s per processor W ×1000 | J per job (processor) | J per job above idle | busy-core GHz | busy CPUs |
|---|---|---|---|---|---|---|---|---|---|---|
| 44 | 6.66 | 0 | 19 | 597 | 538 | 12.4 | 80.7 | 46.9 | 3.39 | 42 |
| 176 | 14.54 | 0 | 22 | 801 | 736 | 19.8 | 50.6 | 35.1 | 3.38 | 142 |
| 352 | 26.29 | 0 | 26 | 1185 | 1108 | 23.7 | 42.1 | 33.6 | 3.37 | 334 |
| 704 | 25.52 | 0 | 27 | 1159 | 1079 | 23.6 | 42.3 | 33.5 | 3.37 | 317 |
| 2000 | 26.25 | 0 | 29 | 1192 | 1109 | 23.7 | 42.3 | 33.7 | 3.37 | 340 |

processor_w = Vera 'AP Power' (both sockets) or AMD RAPL package (both sockets); module_w = Vera 'Total Power' incl. on-module memory; wall_w = BMC reading if available. Confirm the Vera domain definitions before quoting; AMD RAPL excludes DRAM.
